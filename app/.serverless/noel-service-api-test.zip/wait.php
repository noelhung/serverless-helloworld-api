<?php

while (true);